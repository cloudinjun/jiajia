# Paperclip Pal — 36 Draft Paper Uses

基于上传的卡通回形针角色设计的 36 种“草稿纸用法”桌宠状态。单图为透明背景 SVG 与 PNG；表情主要通过眼睛、瞳孔、眉毛、姿态与纸张道具表达，未新增嘴巴。

目录：
- svg/：可编辑矢量源文件
- png/：1024×1024 透明背景 PNG
- manifest.json / manifest.csv：编号、状态 key、中文名称与用途说明
- overview.png / overview.svg：36 款总览
- overview_light_preview.png：浅色背景预览图
