# Paperclip Pal - 36 Draft Paper Uses

基于上传的卡通回形针角色制作的 36 种草稿纸使用状态。所有单独 PNG/SVG 均为透明背景、扁平化画风、无手、无嘴巴设计。

目录：
- png/: 36 个 1024×1024 透明 PNG
- svg/: 36 个可编辑 SVG
- manifest.json / manifest.csv: 每个状态的 key、中文名称、触发场景、表情和设计说明
- overview.png / overview.svg: 6×6 总览图
