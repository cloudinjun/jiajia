Paperclip Pal melting animation keyframes

Timeline:
K0 0%   Original / hold
K1 10%  Softening begins; line subtly sags
K2 22%  Weight drops; first floor puddle appears
K3 35%  Top slumps; face stretches
K4 48%  Eyes/brows drip; body becomes a liquid column
K5 62%  Main collapse into puddle
K6 75%  Low loop; face sinks toward puddle
K7 88%  Almost fully liquefied; remaining ripples
K8 100% Final puddle; readable face remnants

Suggested timing: 1.4-1.6s melt, hold final puddle for 0.3-0.5s, ease-in through K1-K4 and ease-out after K6.
